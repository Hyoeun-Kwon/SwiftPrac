//
//  IDFindViewController.swift
//  Login_P
//
//  Created by HyoEun Kwon on 2021/07/29.
//

import UIKit

class IDFindViewController: UIViewController {

    
    @IBOutlet weak var tfName: UITextField!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    func setUnderLine(){
        
        tfName.borderStyle = .none
        let border = CALayer()
        border.frame = CGRect(x: 0, y: tfName.frame.size.height-1, width: tfName.frame.width, height: 1)
        border.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tfName.layer.addSublayer((border))
        tfName.textAlignment = .left
        tfName.textColor = UIColor.systemGray
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
