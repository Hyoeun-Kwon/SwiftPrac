//
//  ViewController.swift
//  Login_P
//
//  Created by HyoEun Kwon on 2021/07/29.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tfUserId: UITextField!
    @IBOutlet weak var tfUserPassword: UITextField!
    @IBOutlet weak var btnLoginL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //textField 밑줄로 만들기
        setUnderLineId()
        setUnderLinePwd()
        
        //버튼 라운드
        setRadius()
        
        
    }
    
    
    
    
    @IBAction func btnLogin(_ sender: UIButton) {
        if tfUserId.text == "aaa" && tfUserPassword.text == "1111"{
            // id가 통과되면
            Share.userID = tfUserId.text!
            Share.userPwd = tfUserPassword.text!
            // 버튼 눌렀을때 해당 segue로 가게 하겠다.
            self.performSegue(withIdentifier: "sgLoginToMain", sender: self)
            
        }else{//불일치시
            let idAlert = UIAlertController(title: "경고", message: "ID나 암호가 불일치 합니다!", preferredStyle: .alert)
            let idAction = UIAlertAction(title: "확인", style: .default, handler: nil)
            //idAlert.view.backgroundColor = #colorLiteral(red: 0, green: 0.5628422499, blue: 0.3188166618, alpha: 1)
            idAlert.addAction(idAction)
            present(idAlert, animated: true, completion: nil)

        }

    }
    
       
    
    
    
    
    
    //---------------------- 뷰 꾸미는 속성 (텍스트필드, 버튼)
    func setUnderLineId(){
        
        tfUserId.borderStyle = .none
        let border = CALayer()
        border.frame = CGRect(x: 0, y: tfUserId.frame.size.height-1, width: tfUserId.frame.width, height: 1)
        border.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tfUserId.layer.addSublayer((border))
        tfUserId.textAlignment = .left
        tfUserId.textColor = UIColor.systemGray
    }
    
    func setUnderLinePwd(){
        
        tfUserPassword.borderStyle = .none
        let border = CALayer()
        border.frame = CGRect(x: 0, y: tfUserPassword.frame.size.height-1, width: tfUserPassword.frame.width, height: 1)
        border.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tfUserPassword.layer.addSublayer((border))
        tfUserPassword.textAlignment = .left
        tfUserPassword.textColor = UIColor.systemGray
    }
    
    
    func setRadius(){
        btnLoginL.layer.cornerRadius = 20
    }
    
//
//    func setUnderLine() {
//        let border = CALayer()
//        let width = CGFloat(0.5)
//        border.borderColor = UIColor.darkGray.cgColor
//        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width - 10, height: self.frame.size.height)
//        border.borderWidth = width
//        self.layer.addSublayer(border)
//        self.layer.masksToBounds = true
//    }
//
    
    
    
    

}//

