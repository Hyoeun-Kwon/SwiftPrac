//
//  Share.swift
//  Login_P
//
//  Created by HyoEun Kwon on 2021/07/29.
//

import Foundation

struct Share {
    static var userID: String = ""
    static var userPwd: String = ""
    static var IP: String = "http://192.168.35.146"
}
